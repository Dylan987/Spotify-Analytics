function handle_analysis_form() {
  preventDefault();
  var q = this.firstChild.value;
  alert(q);
}
